This experiment has a dependency on the Scalar software.
Build the jar in a seperate project and copy it to the lib directory.
